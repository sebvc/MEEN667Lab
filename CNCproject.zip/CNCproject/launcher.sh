#!/bin/sh
# launcher.sh

cd / 
cd home/pi/Desktop/Tracking_camera
sudo python boot.py
cd /
